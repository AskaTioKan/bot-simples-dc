const { Client } = require('discord.js') /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/

const credito = require('../../creditos.json')
const credito33 = process.env.CREDITO3;

const { readdirSync } = require('fs') /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
const { join } = require('path') /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/

const { connect } = require('mongoose') /*nãoexisto#0001*/
const Models = require('../database/models/Models') /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
const c = require('colors') /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/



module.exports = class extends Client {
    constructor(options) {
        super(options) /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/

        this.commands = [] /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
        this.loadCommands() /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ 
        this.loadEvents() /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*//*nãoexisto#0001*/

    }

    registryCommands() {
        //this.guilds.cache.get('888570451176071239').commands.set(this.commands)
        this.application.commands.set(this.commands) /*nãoexisto#0001*/
    }

    loadCommands(path = 'src/commands') {
        const categories = readdirSync(path) /*nãoexisto#0001*/

        for (const category of categories) {
            const commands = readdirSync(`${path}/${category}`) /*nãoexisto#0001*/

            for (const command of commands) {
                const commandClass = require(join(process.cwd(), `${path}/${category}/${command}`)) /*nãoexisto#0001*/
                const cmd = new (commandClass)(this) /*nãoexisto#0001*/

                this.commands.push(cmd) /*nãoexisto#0001*/
            }
        }
    }

    loadEvents(path = 'src/events') {
        const categories = readdirSync(path) /*nãoexisto#0001*/

        for (const category of categories) {
            const events = readdirSync(`${path}/${category}`) /*nãoexisto#0001*/

            for (const event of events) {
                const eventClass = require(join(process.cwd(), `${path}/${category}/${event}`)) /*nãoexisto#0001*/
                const evt = new (eventClass)(this) /*nãoexisto#0001*/

                this.on(evt.name, evt.run) /*nãoexisto#0001*/
            }
        }
    }

    async connectToDatabase() { 
        const connection = await connect(process.env.MONGO_URL, {
            useNewUrlParser: true, /*nãoexisto#0001*/
            useUnifiedTopology: true, /*nãoexisto#0001*/
            useFindAndModify: false, /*nãoexisto#0001*/
            useCreateIndex: true
        })

        console.log(c.red("[ MONGODB ] - CONECTANDO A DATABASE...")) /*nãoexisto#0001*/
        console.log(c.green("[ MONGODB ] - DATABASE CONECTADA !"))/*nãoexisto#0001*/

        this.db = { connection, ...Models }/*nãoexisto#0001*/
    }
}