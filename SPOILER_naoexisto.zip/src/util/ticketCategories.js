
const { MessageButton, MessageEmbed } = require('discord.js')

const credito33 = process.env.CREDITO3;  /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*//*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
/*
    {
        button: MessageButton,
        embed: MessageEmbed,
        name: String,
        id: String
    }
*/

module.exports = [
    {
        button: new MessageButton().setCustomId(`openTicket-885161395761606776`).setLabel(`ABRIR`).setStyle('SUCCESS'),
        embed: new MessageEmbed().setDescription('Bem vindo ao seu ticket!'),
        name: 'compra',
        id: '888570451176071240', /* id da categoria */ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
        staffRole: '888577759117467768' /* id do cargo staff */ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
    }, /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/ /*nãoexisto#0001*/
]