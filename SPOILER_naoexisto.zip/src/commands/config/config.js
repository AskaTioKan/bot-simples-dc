const Command = require('../../structures/Command')
const credito = require('../../../creditos.json')
const credito33 = process.env.CREDITO8;
const credito99 = process.env.CREDITO3;
const credito77 = process.env.CREDITO7;

module.exports = class extends Command {
    constructor(client) {
        super(client, {
            name: 'config',
            description: 'Configurar dados do servidor no bot.',
            requireDatabase: true,
            options: [
                {
                    type: 'SUB_COMMAND_GROUP',
                    name: 'ticket',
                    description: 'Configuração do sistema de tickets.',
                    options: [
                        {
                            type: 'SUB_COMMAND',
                            name: 'setup',
                            description: 'Mensagem onde o usuário irá clicar para abrir o ticket.',
                            options: [
                                {
                                    type: 'CHANNEL',
                                    name: 'canal',
                                    description: 'Canal de texto onde a mensagem será enviada.',
                                    required: true
                                }
                            ]
                        }
                    ]
                }
            ]
        })
    }

    run = (interaction) => {
        if (!interaction.member.permissions.has('MANAGE_GUILD')) return interaction.reply({ content: 'Sai daqui seu pobre !', ephemeral: true })

        const subCommandGroup = interaction.options.getSubcommandGroup()
        const subCommand = interaction.options.getSubcommand()

        require(`../../subCommands/config/${subCommandGroup}/${subCommand}`)(this.client, interaction)
    }
}