const credito = require('../../../creditos.json')
const credito33 = process.env.CREDITO3;

module.exports = {
    guilds: require('./Guild')
}