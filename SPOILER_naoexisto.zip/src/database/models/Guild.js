const { Schema, model } = require('mongoose')
const credito = require('../../../creditos.json')
const credito33 = process.env.CREDITO3;

const guildSchema = new Schema({
    _id: String,
    welcome: {
        channel: String
    }
})

module.exports = model('guilds', guildSchema)