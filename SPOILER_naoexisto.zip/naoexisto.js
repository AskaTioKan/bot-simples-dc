require('dotenv').config()

const credito33 = process.env.CREDITO3;


const Client = require('./src/structures/Client')

const { Intents } = require('discord.js')
const client = new Client({ intents: [Intents.FLAGS.GUILDS] })

client.login(process.env.TOKEN)