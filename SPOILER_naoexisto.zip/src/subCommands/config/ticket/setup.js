const { MessageEmbed, MessageActionRow } = require('discord.js')
const ticketCategories = require('../../../util/ticketCategories')

module.exports = (client, interaction) => {
    const channel = interaction.options.getChannel('canal')

    if (channel.type !== 'GUILD_TEXT') return interaction.reply({ content: 'Cade o canal de texto ?', ephemeral: true })

    const embed = new MessageEmbed()
        .setDescription('Clique no botâo para abrir um ticket.\n\nNão abra tickets sem motivo!')
        .setColor('32135a')
        .setImage('https://cdn.discordapp.com/attachments/888577935768948746/888580968955396136/994e5335b9e54a2bdee1077049c7d653.png')

    const buttons = ticketCategories.map(c => c.button)
    const row = new MessageActionRow().addComponents(buttons)

    channel.send({ embeds: [embed], components: [row] })

    interaction.reply({ content: 'Canal setado com sucesso!', ephemeral: true })
}